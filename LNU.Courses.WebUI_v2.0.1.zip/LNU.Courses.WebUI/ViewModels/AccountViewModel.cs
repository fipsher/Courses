﻿namespace LNU.Courses.ViewModels
{
    //public class AccountViewModel
    //{
    //    public Account Account { get; set; }
    //}
}