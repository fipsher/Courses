﻿using System;
using System.Web.Configuration;
using LNU.Courses.Jobs;
using LNU.Courses.PeriodicalJobMaker;
using LNU.Courses.WebUI.Models;
using Entities;
using System.Linq;

namespace LNU.Courses.WebUI.App_Start
{
    public class DeadlineConfig
    {
        public static readonly IPeriodicalyJobMaker JobMaker = new JobMaker();

        public static void SetDeadlines()
        {
            var context = new CoursesDataModel();
            JobMaker.ClearSchedule();

            string startPoint = WebConfigurationManager.AppSettings["Start"];
            string[] wordsStart = startPoint.Split(' ');
            JobMaker.Start<StartJob>(startPoint);
            staticData.StartTime = context.Variables.Single(el => el.Key == "Start").Value; //new DateTime(DateTime.Now.Year, Convert.ToInt32(wordsStart[4]), Convert.ToInt32(wordsStart[3]));


            string frstDeadline = WebConfigurationManager.AppSettings["FirstDeadLine"];
            string[] wordsFrst = frstDeadline.Split(' ');

            JobMaker.Start<FirstDeadLineJob>(frstDeadline);
            staticData.firstDeadLineTime = context.Variables.Single(el => el.Key == "FirstDeadline").Value; //new DateTime(DateTime.Now.Year, Convert.ToInt32(wordsFrst[4]), Convert.ToInt32(wordsFrst[3]));

            string lastDeadline = WebConfigurationManager.AppSettings["LastDeadLine"];
            string[] wordsLast = lastDeadline.Split(' ');
            staticData.lastDeadLineTime = context.Variables.Single(el => el.Key == "LastDeadline").Value; //new DateTime(DateTime.Now.Year, Convert.ToInt32(wordsLast[4]), Convert.ToInt32(wordsLast[3]));

            JobMaker.Start<LastDeadlineJob>(lastDeadline);
        }
    }
}